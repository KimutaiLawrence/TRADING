import json
import os
import mt5_interface
import strategy
import time


# Function to import settings from settings.json
def get_project_settings(importFilepath):
    # Test the filepath to sure it exists
    if os.path.exists(importFilepath):
        # Open the file
        f = open(importFilepath, "r")
        # Get the information from file
        project_settings = json.load(f)
        # Close the file
        f.close()
        # Return project settings to program
        return project_settings
    else:
        return ImportError


# Main function
if __name__ == '__main__':
    # Set up the import filepath
    import_filepath = "example_settings.json"
    # Import project settings
    project_settings = get_project_settings(import_filepath)
    # Start MT5
    mt5_interface.start_mt5(project_settings["username"], project_settings["password"], project_settings["server"],
                            project_settings["mt5Pathway"])
    # Initialize symbols
    mt5_interface.initialize_symbols(project_settings["symbols"])
    # Select symbol to run strategy on
    symbol_for_strategy = project_settings['symbols'][0]
    # Set up a previous time variable
    previous_time = 0
    # Set up a current time variable
    current_time = 0
    # Start a while loop to poll MT5
    while True:
        # Retrieve the current candle data
        candle_data = mt5_interface.query_historic_data(symbol=symbol_for_strategy,
                                                        timeframe=project_settings['timeframe'], number_of_candles=1)
        # Extract the timedata
        current_time = candle_data[0][0]
        # Compare against previous time
        if current_time != previous_time:
            # Notify user
            print("New Candle")
            # Update previous time
            previous_time = current_time
            # Retrieve previous orders
            orders = mt5_interface.get_open_orders()
            # Cancel orders
            for order in orders:
                mt5_interface.cancel_order(order)
            # Start strategy one on selected symbol
            strategy.strategy_one(symbol=symbol_for_strategy, timeframe=project_settings['timeframe'],
                                  pip_size=project_settings['pip_size'])
        else:
            # Get positions
            positions = mt5_interface.get_open_positions()
            # Pass positions to update_trailing_stop
            for position in positions:
                strategy.update_trailing_stop(order=position, trailing_stop_pips=10,
                                              pip_size=project_settings['pip_size'])
        time.sleep(0.1)

import MetaTrader5


# Function to start Meta Trader 5 (MT5)
def start_mt5(username, password, server, path):
    # Ensure that all variables are the correct type
    uname = int(username) # Username must be an int
    pword = str(password) # Password must be a string
    trading_server = str(server) # Server must be a string
    filepath = str(path) # Filepath must be a string

    # Attempt to start MT5
    if MetaTrader5.initialize():
        print("Trading Bot Starting")
        # Login to MT5
        if MetaTrader5.login(login=uname, password=pword, server=trading_server):
            print("Trading Bot Logged in and Ready to Go!")
            return True
        else:
            print("Login Fail")
            quit()
            return PermissionError
    else:
        print("MT5 Initialization Failed")
        quit()
        return ConnectionAbortedError


# Function to initialize a symbol on MT5
def initialize_symbols(symbol_array):
    # Get a list of all symbols supported in MT5
    all_symbols = MetaTrader5.symbols_get()
    # Create an array to store all the symbols
    symbol_names = []
    # Add the retrieved symbols to the array
    for symbol in all_symbols:
        symbol_names.append(symbol.name)

    # Check each symbol in symbol_array to ensure it exists
    for provided_symbol in symbol_array:
        if provided_symbol in symbol_names:
            # If it exists, enable
            if MetaTrader5.symbol_select(provided_symbol, True):
                print(f"Sybmol {provided_symbol} enabled")
            else:
                return ValueError
        else:
            return SyntaxError

    # Return true when all symbols enabled
    return True


# Function to place a trade on MT5
def place_order(order_type, symbol, volume, price, stop_loss, take_profit, comment):
    # If order type SELL_STOP
    if order_type == "SELL_STOP":
        order_type = MetaTrader5.ORDER_TYPE_SELL_STOP
    elif order_type == "BUY_STOP":
        order_type = MetaTrader5.ORDER_TYPE_BUY_STOP
    # Create the request
    request = {
        "action": MetaTrader5.TRADE_ACTION_PENDING,
        "symbol": symbol,
        "volume": volume,
        "type": order_type,
        "price": round(price, 3),
        "sl": round(stop_loss, 3),
        "tp": round(take_profit, 3),
        "type_filling": MetaTrader5.ORDER_FILLING_RETURN,
        "type_time": MetaTrader5.ORDER_TIME_GTC,
        "comment": comment
    }
    # Send the order to MT5
    order_result = MetaTrader5.order_send(request)
    # Notify based on return outcomes
    if order_result[0] == 10009:
        print(f"Order for {symbol} successful")
    else:
        print(f"Error placing order. ErrorCode {order_result[0]}, Error Details: {order_result}")
    return order_result


# Function to cancel an order
def cancel_order(order_number):
    # Create the request
    request = {
        "action": MetaTrader5.TRADE_ACTION_REMOVE,
        "order": order_number,
        "comment": "Order Removed"
    }
    # Send order to MT5
    order_result = MetaTrader5.order_send(request)
    return order_result


# Function to modify an open position
def modify_position(order_number, symbol, new_stop_loss, new_take_profit):
    # Create the request
    request = {
        "action": MetaTrader5.TRADE_ACTION_SLTP,
        "symbol": symbol,
        "sl": new_stop_loss,
        "tp": new_take_profit,
        "position": order_number
    }
    # Send order to MT5
    order_result = MetaTrader5.order_send(request)
    if order_result[0] == 10009:
        return True
    else:
        return False


# Function to convert a timeframe string in MetaTrader 5 friendly format
def set_query_timeframe(timeframe):
    # Implement a Pseudo Switch statement. Note that Python 3.10 implements match / case but have kept it this way for
    # backwards integration
    if timeframe == "M1":
        return MetaTrader5.TIMEFRAME_M1
    elif timeframe == "M2":
        return MetaTrader5.TIMEFRAME_M2
    elif timeframe == "M3":
        return MetaTrader5.TIMEFRAME_M3
    elif timeframe == "M4":
        return MetaTrader5.TIMEFRAME_M4
    elif timeframe == "M5":
        return MetaTrader5.TIMEFRAME_M5
    elif timeframe == "M6":
        return MetaTrader5.TIMEFRAME_M6
    elif timeframe == "M10":
        return MetaTrader5.TIMEFRAME_M10
    elif timeframe == "M12":
        return MetaTrader5.TIMEFRAME_M12
    elif timeframe == "M15":
        return MetaTrader5.TIMEFRAME_M15
    elif timeframe == "M20":
        return MetaTrader5.TIMEFRAME_M20
    elif timeframe == "M30":
        return MetaTrader5.TIMEFRAME_M30
    elif timeframe == "H1":
        return MetaTrader5.TIMEFRAME_H1
    elif timeframe == "H2":
        return MetaTrader5.TIMEFRAME_H2
    elif timeframe == "H3":
        return MetaTrader5.TIMEFRAME_H3
    elif timeframe == "H4":
        return MetaTrader5.TIMEFRAME_H4
    elif timeframe == "H6":
        return MetaTrader5.TIMEFRAME_H6
    elif timeframe == "H8":
        return MetaTrader5.TIMEFRAME_H8
    elif timeframe == "H12":
        return MetaTrader5.TIMEFRAME_H12
    elif timeframe == "D1":
        return MetaTrader5.TIMEFRAME_D1
    elif timeframe == "W1":
        return MetaTrader5.TIMEFRAME_W1
    elif timeframe == "MN1":
        return MetaTrader5.TIMEFRAME_MN1


# Function to query previous candlestick data from MT5
def query_historic_data(symbol, timeframe, number_of_candles):
    # Convert the timeframe into an MT5 friendly format
    mt5_timeframe = set_query_timeframe(timeframe)
    # Retrieve data from MT5
    rates = MetaTrader5.copy_rates_from_pos(symbol, mt5_timeframe, 1, number_of_candles)
    return rates


# Function to retrieve all open orders from MT5
def get_open_orders():
    orders = MetaTrader5.orders_get()
    order_array = []
    for order in orders:
        order_array.append(order[0])
    return order_array


# Function to retrieve all open positions
def get_open_positions():
    # Get position objects
    positions = MetaTrader5.positions_get()
    # Return position objects
    return positions


import mt5_interface
import pandas
import numpy


# Function to articulate strategy_one
def strategy_one(symbol, timeframe, pip_size):
    # Retrieve the required data from get_and_transform_mt5_data
    data_df = get_and_transform_mt5_data(symbol=symbol, timeframe=timeframe, number_of_candles=2, pip_size=pip_size)
    print(data_df)
    # Pass this to make_decision
    decision = make_decision(data_df)
    print(decision)
    # Pass the decision and dataframe to create_new_order
    create_new_order(decision_outcome=decision, candle_dataframe=data_df, pip_size=pip_size, symbol=symbol)
    return "Completed"


# Function to query last two candles in MetaTrader 5 based upon timeframe
def get_and_transform_mt5_data(symbol, timeframe, number_of_candles, pip_size):
    # Retrieve the raw data from MT5 platform
    raw_data = mt5_interface.query_historic_data(symbol, timeframe, number_of_candles)
    # Transform raw data into Pandas DataFrame
    df_data = pandas.DataFrame(raw_data)
    # Convert the time in seconds into a human readable datetime format
    df_data['time'] = pandas.to_datetime(df_data['time'], unit='s')
    # Calculate if red or green
    df_data['RedOrGreen'] = numpy.where((df_data['open'] < df_data['close']), 'Green', 'Red')
    # Calculate trade_high (high price + 1 pip)
    df_data['trade_high'] = df_data['high'] + pip_size
    # Calculate trade_low (low price - 1 pip)
    df_data['trade_low'] = df_data['low'] - pip_size
    # Calculate the number of pips between trade_high and trade_low
    df_data['pip_distance'] = (df_data['trade_high'] - df_data['trade_low'])/pip_size
    # Return the data frame to the user
    return df_data


# Function to make decisions based on presented dataframe
def make_decision(candle_dataframe):
    # Test if they are both the same
    if(candle_dataframe.iloc[0]['RedOrGreen'] != candle_dataframe.iloc[1]['RedOrGreen']):
        return "DoNothing"
    # Test if both are Green
    elif(candle_dataframe.iloc[0]['RedOrGreen'] == "Green" and candle_dataframe.iloc[0]['RedOrGreen'] == "Green"):
        return "Green"
    # Test if both are Red
    elif (candle_dataframe.iloc[0]['RedOrGreen'] == "Red" and candle_dataframe.iloc[0]['RedOrGreen'] == "Red"):
        return "Red"
    # Default outcome in case of unforseen error
    else:
        return "DoNothing"


# Function to create a new order based upon previous analysis
def create_new_order(decision_outcome, candle_dataframe, pip_size, symbol):
    # Extract the first row of the dataframe
    first_row = candle_dataframe.iloc[1]
    # Do nothing if outcome is "DoNothing
    if decision_outcome == "DoNothing":
        return
    elif decision_outcome == "Green":
        # Calculate the order stop_loss (trade_low of previous candle)
        stop_loss = first_row['trade_low']
        # Calculate the order buy_stop (trade_high of previous candle)
        buy_stop = first_row['trade_high']
        # Calculate the order take_profit (2 times the pip distance, added to the buy_stop)
        num_pips = first_row["pip_distance"] * 2 * pip_size # Convert pip_distance back into pips
        take_profit = buy_stop + num_pips
        # Add in an order comment
        comment = "Green Order"
        # Send order to place_order function in mt5_interface.py
        mt5_interface.place_order("BUY_STOP", symbol, 0.1, buy_stop, stop_loss, take_profit, comment)
        return
    elif decision_outcome == "Red":
        # Calculate the order stop_loss (trade_high of previous candle)
        stop_loss = first_row['trade_high']
        # Calculate the order buy_stop (trade_low of previous candle)
        buy_stop = first_row['trade_low']
        # Calculate the order take_profit (2 times the pip distance, subtracted from the buy_stop)
        num_pips = first_row["pip_distance"] * 2 * pip_size  # Convert pip_distance back into pips
        take_profit = buy_stop - num_pips
        # Add in an order comment
        comment = "Red Order"
        # Send order to place_order function in mt5_interface.py
        mt5_interface.place_order("SELL_STOP", symbol, 0.1, buy_stop, stop_loss, take_profit, comment)
        return


# Function to update trailing stop if needed
def update_trailing_stop(order, trailing_stop_pips, pip_size):
    # Convert trailing_stop_pips into pips
    trailing_stop_pips = trailing_stop_pips * pip_size
    # Determine if Red or Green
    # A Green Position will have a take_profit > stop_loss
    if order[12] > order[11]:
        # If Green, new_stop_loss = current_price - trailing_stop_pips
        new_stop_loss = order[13] - trailing_stop_pips
        # Test to see if new_stop_loss > current_stop_loss
        if new_stop_loss > order[11]:
            print("Update Stop Loss")
            # Create updated values for order
            order_number = order[0]
            symbol = order[16]
            # New take_profit will be the difference between new_stop_loss and old_stop_loss added to take profit
            new_take_profit = order[12] + new_stop_loss - order[11]
            print(new_take_profit)
            # Send order to modify_position
            mt5_interface.modify_position(order_number=order_number, symbol=symbol, new_stop_loss=new_stop_loss,
                                          new_take_profit=new_take_profit)
    elif order[12] < order[11]:
        # If Red, new_stop_loss = current_price + trailing_stop_pips
        new_stop_loss = order[13] + trailing_stop_pips
        # Test to see if new_stop_loss < current_stop_loss
        if new_stop_loss < order[11]:
            print("Update Stop Loss")
            # Create updated values for order
            order_number = order[0]
            symbol = order[16]
            # New take_profit will be the difference between new_stop_loss and old_stop_loss subtracted from old take_profit
            new_take_profit = order[12] - new_stop_loss + order[11]
            print(new_take_profit)
            # Send order to modify_position
            mt5_interface.modify_position(order_number=order_number, symbol=symbol, new_stop_loss=new_stop_loss,
                                          new_take_profit=new_take_profit)



