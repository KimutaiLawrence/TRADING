import MetaTrader5 as mt5
import numpy as np
import pandas as pd
import tensorflow as tf

# Connect to MT5
if not mt5.initialize():
    print("initialize() failed")
    mt5.shutdown()

# Define function to get historical prices
def get_historical_prices(symbol, timeframe, start_time, end_time):
    rates = mt5.copy_rates_range(symbol, timeframe, start_time, end_time)
    prices = pd.DataFrame(rates)
    prices['time'] = pd.to_datetime(prices['time'], unit='s')
    prices.set_index('time', inplace=True)
    prices.drop(['spread', 'real_volume'], axis=1, inplace=True)
    return prices

# Define function to predict the next price movement
def predict_price_movement(prices, model):
    # Convert prices to numpy array
    prices_array = prices.values

    # Normalize prices
    mean = prices_array.mean()
    std = prices_array.std()
    prices_array = (prices_array - mean) / std

    # Reshape prices array to 3D tensor for input to model
    input_data = np.reshape(prices_array, (1, prices_array.shape[0], prices_array.shape[1]))

    # Predict next price movement using model
    prediction = model.predict(input_data)

    # Denormalize prediction
    prediction = prediction * std + mean

    # Return prediction as a float
    return float(prediction[0][0])

# Define function to place a trade
def place_trade(symbol, trade_type, lots, stop_loss, take_profit):
    order = {
        'action': mt5.TRADE_ACTION_DEAL,
        'symbol': symbol,
        'volume': lots,
        'type': trade_type,
        'deviation': 10,
        'magic': 123456,
        'comment': 'Automated trade',
        'type_time': mt5.ORDER_TIME_GTC,
        'type_filling': mt5.ORDER_FILLING_FOK,
        'expiration': mt5.ORDER_TIME_GTC,
        'type_stop': mt5.ORDER_STOPLOSS,
        'type_take': mt5.ORDER_TAKE_PROFIT,
        'price_stop': stop_loss,
        'price_take': take_profit
    }
    result = mt5.order_send(order)
    return result

# Load AI model
model = tf.keras.models.load_model('model.h5')

# Set symbol and timeframe
symbol = 'EURUSD'
timeframe = mt5.TIMEFRAME_M5

# Set start and end times for historical prices
start_time = pd.to_datetime('2022-01-01')
end_time = pd.to_datetime('2022-02-01')

# Get historical prices
prices = get_historical_prices(symbol, timeframe, start_time, end_time)

# Predict next price movement
prediction = predict_price_movement(prices, model)

# Place trade based on prediction
if prediction > 0:
    place_trade(symbol, mt5.ORDER_TYPE_BUY, 0.1, prices.iloc[-1]['close'] - 0.001, prices.iloc[-1]['close'] + 0.002)
else:
    place_trade(symbol, mt5.ORDER_TYPE_SELL, 0.1, prices.iloc[-1]['close'] + 0.001, prices.iloc[-1]['close'] - 0.002)

# Disconnect from MT5
mt5.shutdown()
