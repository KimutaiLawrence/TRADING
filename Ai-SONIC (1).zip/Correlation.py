import MetaTrader5 as mt5
import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
import itertools
from PyCalendar import StreamCalendar

# Initialize MT5
if not mt5.initialize():
    print("MT5 initialization failed, error code : ", mt5.last_error())
    exit()


# List of all symbols
symbols_list = []
for symbol in mt5.symbols_get():
    symbols_list.append(symbol.name)


# Extract 1Min rates of all symbols from MT5
def Get_Symbol_diff(symbol : str, date_from : datetime, date_to : datetime):
    rates = mt5.copy_rates_range(symbol, mt5.TIMEFRAME_M1, date_from, date_to)
    df = pd.DataFrame(rates) 
    
    df.columns = ["Time", "Open", "High", "Low", "Close", "Ticks Volume", "Spread", "Real Volume"]
    df = df[["Time", "Open", "Close"]]

    df["Open Diff"] = df["Open"].diff()
    df["Close Diff"] = df["Close"].diff()
    return df



date_from = datetime(2022,11,9)
date_to = datetime(2022,11,10)

#Store All symbols Diffs 

Diff_db = []
method = "Open" # you can choose Close as well

for symbol in symbols_list:
    df = Get_Symbol_diff(symbol, date_from, date_to)
    Diff_db.append(df[method+" Diff"])

def Correlation(symbol1 : str, symbol2 : str):
    df1 = Diff_db[symbols_list.index(symbol1)]
    df2 = Diff_db[symbols_list.index(symbol2)]

    min_len = min(df1.shape[0], df2.shape[0])

    df1 = df1.iloc[1:min_len]
    df2 = df2.iloc[1:min_len]

    x, y = np.array(df1), np.array(df2)

    xAsInts = x

    pearR = np.corrcoef(xAsInts,y)[1,0]
    A = np.vstack([xAsInts,np.ones(len(xAsInts))]).T
    m,c = np.linalg.lstsq(A,np.array(y),rcond=None)[0]

    return round(pearR,2)


    plt.scatter(x, y)
    plt.plot(x, x*m+c, color="red")
    plt.show()

symbols_combinations = list(itertools.combinations(symbols_list,2))

symbols_correlation = []

for pair in symbols_combinations :
    symbols_correlation.append((pair, Correlation(pair[0] ,pair[1])))

Corr_df = pd.DataFrame(symbols_correlation)

Corr_df.columns = ["Pair", "R²"] 
Corr_df.dropna()
Corr_df.sort_values("R²", ascending=False)

print(Corr_df)

while True : 
    pass
    #StreamCalendar()